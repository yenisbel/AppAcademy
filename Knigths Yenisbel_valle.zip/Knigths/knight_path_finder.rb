require 'pry'
class KnightPathFinder
    
    attr_reader :start_pos
    VARS_I = [-2,-1, 1, 2,  2,  1, -1, -2]
    VARS_J = [1,  2, 2, 1, -1, -2, -2, -1]


    def initialize(start_pos)
        @start_pos = start_pos
    end

    def find_path(end_pos)
        queue = [@start_pos]
        visited = { @start_pos => [@start_pos] } # => <{pos,   path }>  

        while !queue.empty?
            first = queue.shift
            
            # return all path 
            return visited[first] if first == end_pos
            n_postions = nexts(first)
            
            n_postions.each do |pos|
                next if visited[:pos]
                visited[pos] = visited[first] + [pos] 
                queue << pos
            end
        end
        []
    end

    private


    def nexts(position) 
        potential_nexts = []
        row, col = position  
        8.times do |k|
            new_row = row + VARS_I[k]
            new_col = col + VARS_J[k]
            new_pos = [new_row, new_col] 
            potential_nexts << new_pos if is_valid? new_pos
        end
        potential_nexts
    end

    def is_valid?(position)
        row, col = position
        row >= 0 && row < 8 && col >= 0 && col < 8  
    end

end


require 'rspec/autorun'
RSpec.describe KnightPathFinder do
    let(:kpf) { KnightPathFinder.new([0,0]) }

    it "Initialize of Node" do
        expect(kpf).to be_truthy
    end

    it "Find Path to end pos from start_pos" do
        expect(kpf.send(:nexts, [4, 4])).to eq [[2, 5], [3, 6], [5, 6], [6, 5], [6, 3], [5, 2], [3, 2], [2, 3]]
    end

    it "Find Path to end pos from start_pos" do
        expect(kpf.find_path([2, 1])).to eq [[0, 0], [2, 1]]
        expect(kpf.find_path([3, 3])).to eq [[0, 0], [2, 1], [3, 3]]
    end 
end