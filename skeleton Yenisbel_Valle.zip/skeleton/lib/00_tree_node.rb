
module Searchable
    def dfs(target = nil)
        return self if @value == target
        @children.each do |child|
            decendant = child.dfs(target)
            return decendant unless decendant.nil?
        end
       nil
    end 

    def bfs(target = nil)
        return self if @value == target
        nodes = [self]
        until nodes.empty?
            node = nodes.shift
            return node if node.value == target
            nodes.concat(node.children)
        end  
    end
end

class PolyTreeNode
    include Searchable
    attr_reader :value , :children , :parent
    def initialize(value)
        @value = value
        #@parent = PolyTreeNode.new(value)
        @parent = nil
        @children = []
    end

    

    def parent=(parent)
        return parent if self.parent == parent   
        
        if self.parent
            self.parent.children.delete(self)
        end
        @parent = parent
        self.parent.children << self unless self.parent.nil?  
        
       
    end

    def add_child(child)
        child.parent = self   
    end
    
    def remove_child(child)
        if child && !self.children.include?(child)
            raise "Error!"
        end 
        child.parent = nil
    end
 
end



