class GraphNode
    attr_accessor :neigboors
    
    def self.bfs(starting_node, target_value)
        queue = [starting_node]
        visited = {}
        while !queue.empty?
            first = queue.shift
            if visited[first]
                next
            else
                visited[first] = true
            end
            return true if first == target_value 
            queue += first.neigboors
        end
        false
    end


    def initialize(value, neigboors = [])
        @value = value
        @neigboors = neigboors
        @visited = {}
    end

   

end



require 'rspec/autorun'
RSpec.describe GraphNode do
    let(:node_a) {GraphNode.new('A') }
    let(:node_b) {GraphNode.new('B') }
    let(:node_c) {GraphNode.new('C') }

    it "Initialize of Node" do
        expect(node_a).to be_truthy
    end

    it "Initialize new node with neighboors" do
        neigboors = [node_a, node_c]
        node_d = GraphNode.new('D', neigboors)
        expect(node_d.neigboors).to eq neigboors
    end

    it "Assign neighboor to a node" do
        neigboor = [node_c]
        node_b.neigboors = neigboor
        expect(node_b.neigboors).to eq neigboor
    end

    it "Searching path using BFS" do
        a = GraphNode.new('a')
        b = GraphNode.new('b')
        c = GraphNode.new('c')
        d = GraphNode.new('d')
        e = GraphNode.new('e')
        f = GraphNode.new('f')
        a.neigboors = [b, c, e]
        c.neigboors = [b, d]
        e.neigboors = [a]
        f.neigboors = [e]
        expect(GraphNode.bfs(a, b)).to eq true
        expect(GraphNode.bfs(a, f)).to eq false
    end
end


