# PHASE 2



def convert_to_int(str)
  begin
    Integer(str)
  rescue ArgumentError 
    puts "Integer cannot be string"
    return nil
  end
end

# PHASE 3
FRUITS = ["apple", "banana", "orange"]

class CoffeeError < StandardError
  def message
     "I need more caffein"
  end
end

class FruitReaction < StandardError
  def message
    "Give me a real fruit!"
  end
end

def reaction(maybe_fruit)
  if FRUITS.include? maybe_fruit
    puts "OMG, thanks so much for the #{maybe_fruit}!"
  elsif maybe_fruit == 'coffee' 
    raise CoffeeError 
  else
    raise FruitReaction
  end 
end

def feed_me_a_fruit
  puts "Hello, I am a friendly monster. :)"
  begin
    puts "Feed me a fruit! (Enter the name of a fruit:)"
    maybe_fruit = gets.chomp
    reaction(maybe_fruit) 
  rescue CoffeeError => e
    p e.message
    retry
  rescue FruitReaction => e
    p e.message
  end
end

class FullNameError < ArgumentError
  def message
    p "You must enter a real name"
  end
end

class YearsError < ArgumentError
  def message
    p "Not long enough for best friends"
  end
end

class FavError < ArgumentError
  def message
    p "You must enter a real sport or hobby"
  end
end

# PHASE 4
class BestFriend
  def initialize(name, yrs_known, fav_pastime)
    raise FullNameError if name.length <= 0 
    raise YearsError if yrs_known < 5 
    raise FavError if fav_pastime.length <= 0
    @name = name
    @yrs_known = yrs_known 
    @fav_pastime = fav_pastime
  end

  def talk_about_friendship
    puts "Wowza, we've been friends for #{@yrs_known}. Let's be friends for another #{1000 * @yrs_known}."
  end

  def do_friendstuff
    puts "Hey bestie, let's go #{@fav_pastime}. Wait, why don't you choose. 😄"
  end

  def give_friendship_bracelet
    puts "Hey bestie, I made you a friendship bracelet. It says my name, #{@name}, so you never forget me." 
  end
end

# 0- ArgumentError
# 1- to raise an descriptive error when yrs_known is less than 5.
# 2- BestFriend new to create a real friendship (yrs_known>= 5)
# 3- Update the initialize method to raise descriptive errors 
# when given strings of length <= 0.

