require_relative 'employee'

class Manager < Employee
    attr_reader :subordinates
    
    def initialize(name, title, salary, boss)
        super(name, title, salary, boss)
        @subordinates = []
    end
end

ned = Manager.new("Ned", "Founder", 1000000, nil)
darren = Manager.new("Darren", "Manager", 78000, "Ned")
shawna = Employee.new("Shawna", "TA", 12000, "Darren")
david = Employee.new("David", "TA", 10000, "Darren")

ned.subordinates << darren.salary
ned.subordinates << shawna.salary
ned.subordinates << david.salary

darren.subordinates << shawna.salary
darren.subordinates << david.salary

# p ned.bonus(2)
# p '-----------'
# p darren.bonus(2)
# p '-----------'
# p shawna.bonus(2)
# p '-----------'
# p david.bonus(2)

# p ned.subordinates
# p '----'
# p darren.subordinates

p ned.bonus(5)
p darren.bonus(4)
p david.bonus(3)
