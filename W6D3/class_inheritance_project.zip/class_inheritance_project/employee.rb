class Employee
    attr_reader :name, :title, :salary, :boss
    attr_accessor :bonus

    def initialize(name, title, salary, boss)
        @name = name
        @title = title
        @salary = salary
        @boss = boss 
    end

    def bonus(multiplier)
       if !(self.boss.nil? || self.title == "Manager" )    
        bonus = self.salary * multiplier
        return bonus 
       else
        total_salaries = []
        self.subordinates.each do |salary|
            total_salaries << salary
        end
        return total_salaries.sum * multiplier
       end
    end
end


shawna = Employee.new("Shawna", "TA", 12000, "Darren")
david = Employee.new("David", "TA", 10000, "Darren")

